/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academia;

/**
 *
 * @author Turato
 */
public class AlunoTreino {
    
    private final int cod_aluno;
    private final String cod_treino;

    public AlunoTreino(int cod_aluno, String cod_treino) {
        this.cod_aluno = cod_aluno;
        this.cod_treino = cod_treino;
    }

    
    
    /**
     * Get the value of cod_treino
     *
     * @return the value of cod_treino
     */
    public String getCod_treino() {
        return cod_treino;
    }

    /**
     * Get the value of cod_aluno
     *
     * @return the value of cod_aluno
     */
    public int getCod_aluno() {
        return cod_aluno;
    }

}
