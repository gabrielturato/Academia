/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academia;

import java.util.List;

/**
 *
 * @author Turato
 */
public class Academia {
    class AlunosInativos{
        List<Inativo> inativos;
        
        public AlunosInativos(){
        }
        /**
         * Adiciona aluno inativo ao lista inativos
         */
        public boolean adicionaAluno(Inativo a){
            return inativos.add(a);
        }
        /**
         * Busca aluno na lista e o deleta da lista de inativos
         * E o envia para a lista de ativos (falta implementar)
         */
        public boolean reativaAluno(int codigo){
            Inativo a = inativos.get(codigo);
            if(inativos.contains(a)==true){
                //ativos.add(a) --> Adicionar a lista de ativos, falta implementar
                return inativos.remove(a);
            }else{
                return false;
            }
        }
        
         /**
         * Busca aluno na lista e devolve o objeto
         * Caso não ache retorna null
         */
        public Inativo buscaInativo(int codigo){
            Inativo a = inativos.get(codigo);
            if(inativos.contains(a)==true){
                return a;
            }else{
                return null;
            }
        }
    }
    class AlunosAtivos{
        List<Ativo> ativos;
        
        public AlunosAtivos(){
        }
        /**
         * Adiciona aluno inativo ao lista ativos
         */
        public boolean adicionaAluno(Ativo a){
            return ativos.add(a);
        }
        /**
         * Busca aluno na lista e o deleta da lista de ativos
         * E o envia para a lista de inativos (falta implementar)
         */
        public boolean desativaAluno(int codigo){
            Ativo a = ativos.get(codigo);
            if(true==ativos.contains(a)){
                /*inativos.add(a); Adicionar aluno a lista de inativos*/
                return ativos.remove(a); 
            }else{
                return false;
            }
        }
        /**
         * Busca aluno na lista e devolve o objeto
         * Caso não ache retorna null
         */
        public Ativo buscaAtivo(int codigo){
            Ativo a = ativos.get(codigo);
            if(true==ativos.contains(a)){
                return a;
            }else{
                return null;
            }
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    }
    
}
