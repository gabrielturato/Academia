/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academia;

/**
 *
 * @author Turato
 */
public class Inativo extends Aluno{
    
    public Inativo(int cod_aluno) {
        super(cod_aluno);
    }
}
