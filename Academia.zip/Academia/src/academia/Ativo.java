/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package academia;

/**
 *
 * @author Turato
 */
public class Ativo extends Aluno{
    public Ativo(int cod_aluno) {
        super(cod_aluno);
    }
}
